#include "simulation.h"
#ifndef ANIMAL_H
#define ANIMAL_H

/**
 * TODO: You will need to extend this quite a bit the full 
 * functionality in this assignment.  This includes adding
 * variables and methods to the Animal class, as well as 
 * defining subclasses for Female, Male, and SuperMale
 * 
 */
class Animal {
    protected:
        Simulation* simulation;
        float x, y;
        float vx, vy;
        float timeAlive;
        int r, g, b;
    
    public:
        Animal(Simulation* simulation);
        virtual ~Animal(){};
        virtual void move(float dt);
        virtual void step(float dt);
        virtual void draw();
        bool shouldDie();
        float getDist(Animal* B);

};


class Ball {
    protected:
        Simulation* simulation;
        float vx, vy;
        float timeAlive;
        int r, g, b;
        float dt;
    
    public:
        float x, y;
        Ball(Simulation* simulation);
        virtual ~Ball(){};
        virtual void move(float dt);
        virtual void step(float dt);
        virtual void draw();
        bool shouldDie();
        float getDist(Ball* B);
        float getDist(Player* B);
        float getDist(Goal* B);

};

class Player {
    protected:
        Simulation* simulation;
        float vx, vy;
        int r, g, b;
        int teamColor;
    
    public:
        Player(Simulation* simulation);
        Player(Simulation* simulation, float x, float y, int teamColor);
        float x, y;
        virtual ~Player(){};
        virtual void move(float dt);
        virtual void step(float dt);
        virtual void draw();
        float getDist(Ball* B);
        int getTeamColor(){
            return teamColor;
        }

};

class Goal {
    protected:
        Simulation* simulation;
        int r, g, b;
        int teamColor;
    
    public:
        float x, y;
        Goal(Simulation* simulation, int teamColor);
        virtual ~Goal(){};
        virtual void draw();
        float getDist(Ball* B);

};


#endif