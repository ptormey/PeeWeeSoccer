#include "simulation.h"
#include "animal.h"
#include "randutils.h"
#include <stdio.h>
#include <math.h>
#include <iostream>
using namespace std;

Animal::Animal(Simulation* simulation){
    this->simulation = simulation;
    RandFloat rand;
    timeAlive = 0;
    x = rand.nextFloat();
    y = rand.nextFloat();
    vx = 0.4*(rand.nextFloat()-0.5);
    vy = 0.4*(rand.nextFloat()-0.5);
    r = 0;
    g = 0;
    b = 0;
}

void Animal::move(float dt) {
    x += dt*vx;
    y += dt*vy;
    if (x < 0) {
        x = 0;
        vx *= -1;
    }
    if (x > 1) {
        x = 1;
        vx *= -1;
    }
    if (y < 0) {
        y = 0;
        vy *= -1;
    }
    if (y > 1) {
        y = 1;
        vy *= -1;
    }
}

void Animal::draw() {
    float diam = 0.005;
    if (timeAlive > simulation->getAdultTime()) {
        diam = 0.01;
    }
    simulation->circle(x, y, r, g, b, diam);
}

void Animal::step(float dt) {
    timeAlive += dt;
    move(dt);

    Animal* B = simulation->getNearest(this);
    if (B != NULL) {
        float d = getDist(B);
        if (d > 0.1) {
            vx = 0.1*(B->x - x)/d;
            vy = 0.1*(B->y - y)/d;
        }
    }
}

bool Animal::shouldDie() {
    bool ret = false;
    if (timeAlive > simulation->getLifetime()) {
        ret = true;
    }
    return ret;
}

/**
 * @brief Compute the distance between this and another animal
 * 
 * @param B Other animal
 * @return float 
 */
float Animal::getDist(Animal* B) {
    float res = (x - B->x)*(x - B->x);
    res += (y - B->y)*(y - B->y);
    return sqrt(res);
}


Ball::Ball(Simulation* simulation){
    this->x = 0.5;
    this->y = 0.5;

    this->r = 0;
    this->g = 0;
    this->b = 0;

    RandFloat rand;
    vx = 0.4*(rand.nextFloat()-0.5);
    vy = 0.4*(rand.nextFloat()-0.5);

    this->simulation = simulation;
}

void Ball::move(float dt) {
    float time = time + dt;
    x += dt*vx;
    y += dt*vy;
    if (x < 0) {
        x = 0;
        vx *= -1;
    }
    if (x > 1) {
        x = 1;
        vx *= -1;
    }
    if (y < 0) {
        y = 0;
        vy *= -1;
    }
    if (y > 1) {
        y = 1;
        vy *= -1;
    }
    if(dt >= 2){
        vx = 0;
        vy = 0;
    }
}

void Ball::draw() {
    float diam = 0.009;
    simulation->circle(x, y, r, g, b, diam);
}

void Ball::step(float dt) {
    timeAlive += dt;
    //move(dt);
    Player* nearestPlayer = this->simulation->getNearest(this);

    float dist = this->getDist(nearestPlayer);
    if (dist < 0.05) {
        //cout << nearestPlayer->getTeamColor() << "\n";
        if(nearestPlayer->getTeamColor() == simulation->red) {
            Goal* goalBlue = this->simulation->getGoal(this->simulation->blue);
            float d = getDist(goalBlue);
            if (d > 0.1) {
                vx = 0.1*(goalBlue->x - x)/d;
                vy = 0.1*(goalBlue->y - y)/d;
            }
        }else{
            Goal* goalRed = this->simulation->getGoal(this->simulation->red);
            float d = getDist(goalRed);
            if (d > 0.1) {
                vx = 0.1*(goalRed->x - x)/d;
                vy = 0.1*(goalRed->y - y)/d;
            }
        }

        //float time = time + dt;
        x += dt*vx;
        y += dt*vy;
    }
}

/**
 * @brief Compute the distance between this and another Ball
 * 
 * @param B Other Ball
 * @return float 
 */
float Ball::getDist(Ball* B) {
    float res = (x - B->x)*(x - B->x);
    res += (y - B->y)*(y - B->y);
    return sqrt(res);
}

float Ball::getDist(Goal* B) {
    float res = (x - B->x)*(x - B->x);
    res += (y - B->y)*(y - B->y);
    return sqrt(res);
}

float Ball::getDist(Player* B) {
    float res = (x - B->x)*(x - B->x);
    res += (y - B->y)*(y - B->y);
    return sqrt(res);
}


Player::Player(Simulation* simulation){
    this->simulation = simulation;
    RandFloat rand;
    x = rand.nextFloat();
    y = rand.nextFloat();
    vx = 0.4*(rand.nextFloat()-0.5);
    vy = 0.4*(rand.nextFloat()-0.5);
    r = 0;
    g = 0;
    b = 0;
}


Player::Player(Simulation* simulation, float x, float y, int teamColor) {
    this->teamColor = teamColor;
    this->simulation = simulation;
    RandFloat rand;
    this->x = x;
    this->y = y;

    vx = 0.4*(rand.nextFloat()-0.5);
    vy = 0.4*(rand.nextFloat()-0.5);
    if (this->teamColor == this->simulation->blue) {
        r = 0;
        g = 0;
        b = 255;
    } else {
        r = 255;
        g = 0;
        b = 0;
    }

}


void Player::move(float dt) {
    x += dt*vx;
    y += dt*vy;
    if (x < 0) {
        x = 0;
        vx *= -1;
    }
    if (x > 1) {
        x = 1;
        vx *= -1;
    }
    if (y < 0) {
        y = 0;
        vy *= -1;
    }
    if (y > 1) {
        y = 1;
        vy *= -1;
    }
}

void Player::draw() {
    float diam = 0.02;
    simulation->circle(x, y, r, g, b, diam);
}

void Player::step(float dt) {
    //cout << this->vx;
   // move(dt);

    //* B = simulation->getNearest(this);
    /*
    if (B != NULL) {
        float d = getDist(B);
        if (d > 0.1) {
            vx = 0.1*(B->x - x)/d;
            vy = 0.1*(B->y - y)/d;
        }
    }
    */
   this->move(dt);
    Ball* ball = simulation->getBall();
    //if (B != NULL) {
        float d = getDist(ball);
        if (d > 0.075) {
            RandFloat rand;


            vx = 0.5 * rand.nextFloat()*(ball->x - x)/d;
            vy = 0.5 * rand.nextFloat()*(ball->y - y)/d;
        }
    //}
}

/**
 * @brief Compute the distance between this and another animal
 * 
 * @param B Other animal
 * @return float 
 */


float Player::getDist(Ball* B) {
    float res = (x - B->x)*(x - B->x);
    res += (y - B->y)*(y - B->y);
    return sqrt(res);
}




Goal::Goal(Simulation* simulation, int teamColor) {
    this->simulation = simulation;
    RandFloat rand;
    this->x = x;
    this->y = y;
    if (teamColor == this->simulation->blue) {
        x = 0.001;
        y = 0.50;
        r = 0;
        g = 0;
        b = 255;
    } else {
        x = 0.999;
        y = 0.50;
        r = 255;
        g = 0;
        b = 0;
    }

}



void Goal::draw() {
    float diam = 0.08;
    simulation->circle(x, y, r, g, b, diam);
}
/*
void Goal::step(float dt) {
   // move(dt);

    //* B = simulation->getNearest(this);
    /*
    if (B != NULL) {
        float d = getDist(B);
        if (d > 0.1) {
            vx = 0.1*(B->x - x)/d;
            vy = 0.1*(B->y - y)/d;
        }
    }
    */
   /*
   this->move(dt);
    Ball* ball = simulation->getBall();
    //if (B != NULL) {
        float d = getDist(ball);
        if (d > 0.1) {
            vx = 0.1*(ball->x - x)/d;
            vy = 0.1*(ball->y - y)/d;
        }
    //}
    
}
*/
/**
 * @brief Compute the distance between this and another animal
 * 
 * @param B Other animal
 * @return float 
 */


float Goal::getDist(Ball* B) {
    float res = (x - B->x)*(x - B->x);
    res += (y - B->y)*(y - B->y);
    return sqrt(res);
}