#include <vector>
#include <iostream>
#include "simulation.h"

using namespace std;


int main() {
  Simulation simulation(800, 5, 20);
  simulation.run();
  return 0;
}