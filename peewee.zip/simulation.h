#ifndef SIMULATION_H
#define SIMULATION_H

#include <list>

using namespace std;

class Animal;
class SimulationCanvas;
class Ball ;
class Goal ;
class Player;

class Simulation {
    private:
        float res;
        list<Animal*> animals;

        list<Player*> players;
        SimulationCanvas* canvas;
        Ball* ball;

        Goal* goalRed;
        Goal* goalBlue;


        float adultTime;
        float lifetime;
    
    public:
        const static int red = 0;
        const static int blue = 1;
        /**
         * @brief Construct a new simulation object
         * 
         * @param res The square resolution of the window
         */
        Simulation(int res, int adultTime, int lifetime);
        ~Simulation();

        void circle(float x, float y, int r, int g, int b, float diameter);
        void square(float x, float y, int r, int g, int b, float width, float height);
        void step(float dt);
        void run();
        Ball* getBall() {
            return this->ball;
        }
        float getAdultTime(){
            return adultTime;
        }
        float getLifetime() {
            return lifetime;
        }
        Animal* getNearest(Animal* A);

        Player* getNearest(Ball* A);

        Goal* getGoal(int teamColor){
            if (teamColor == this->red){
                return this->goalRed;
            }else{
                return this->goalBlue;
            }
        }
};

#endif